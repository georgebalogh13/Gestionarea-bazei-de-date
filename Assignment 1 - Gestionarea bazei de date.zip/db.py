import sqlite3
import random
conn = sqlite3.connect("books.db")

cursor = conn.cursor()

cursor.execute("""CREATE TABLE IF NOT EXISTS Books( id INT PRIMARY KEY, title TEXT, year INT);""")
# cursor.commit()


def insert():
    title = input("Book title: ")
    year = input ("Book year")
   
    book = {"id": random.randrange(100),"title" : title, "year" : year}

    print("Inserting in db...")
    cursor.execute("INSERT INTO Books values (:id, :title, :year)", book)
    conn.commit()

def readBooksFromDb():
    cursor.execute("SELECT * FROM Books")
    books = cursor.fetchall()
    print(books)
    
insert()
readBooksFromDb()